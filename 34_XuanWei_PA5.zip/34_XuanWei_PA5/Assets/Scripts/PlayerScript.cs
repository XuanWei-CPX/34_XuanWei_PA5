﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerScript : MonoBehaviour
{
    [Tooltip("Speed of the player")]
    public float MovementSpeed;

    [Tooltip("Shooting rate of the player")]
    public float ShootingRate;

    [Tooltip("Damage on enemy on each hit")]
    public int ShootingDamage;

    [Tooltip("Starting health of the enemy")]
    public int HealthPoint;

    [Tooltip("Starting ammo of the enemy")]
    public int AmmoCount;

    [Tooltip("Player bullet prefeb")]
    public GameObject PlayerBullet;

    [Tooltip("Shooting sound effect")]
    public AudioClip ShootingAudioClip;

    public int score = 0;


    private Rigidbody rb = null;
    private Vector3 moveDirection = Vector3.zero;
    private bool canShoot;
    private AudioSource audioSource;

    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        audioSource = GetComponent<AudioSource>();

        canShoot = true;
        audioSource.clip = ShootingAudioClip;

        GameManager.Instance.UpdateAmmo(AmmoCount);
        GameManager.Instance.UpdateHealth(HealthPoint);
    }

    // Update is called once per frame
    void Update()
    {
        if (GameManager.Instance.isGameOver)
            return;

        UpdateMovement();
        UpdateRotation();
        Shoot();

        if(score == 5)
        {
            SceneManager.LoadScene("Win");
            print(1);
        }
    }

    private void UpdateMovement()
    {
        // Get the direction based on the user input
        moveDirection = new Vector3(Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical"));
        moveDirection.Normalize();

        // Set the velocity to the direction * movement speed
        rb.velocity = new Vector3(moveDirection.x * MovementSpeed, 
                                  rb.velocity.y, 
                                  moveDirection.z * MovementSpeed);
    }

    private void UpdateRotation()
    {
        // The step size is dependent on the delta time.
        float step = MovementSpeed * 3 * Time.deltaTime;
        Vector3 newDir = Vector3.RotateTowards(transform.forward, moveDirection, step, 0.0f);

        // Rotate our position a step closer to the target.
        transform.rotation = Quaternion.LookRotation(newDir);
    }
    
    private void Shoot()
    {
        if (Input.GetButton("Fire1") && canShoot && AmmoCount > 0) {
            StartCoroutine(SpawnBullet());
        }
    }

    private IEnumerator SpawnBullet()
    {

        GameManager.Instance.UpdateAmmo(--AmmoCount);

        canShoot = false;
        //wait for some time
        yield return new WaitForSeconds(ShootingRate);

        canShoot = true;
    }

    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.tag == "Wall")
        {
            SceneManager.LoadScene("Lose");
        }
        if(collision.gameObject.tag == "Coin")
        {
            score += 1;
        }
    }

    private void Dead() {
        Destroy(gameObject);
    }

    public void AddAmmo(int ammo, AudioClip audioClip) {
        AmmoCount += ammo;
        GameManager.Instance.UpdateAmmo(AmmoCount);

        audioSource.PlayOneShot(audioClip);
    }

    public void AddHealth(int health, AudioClip audioClip)
    {
        HealthPoint += health;
        GameManager.Instance.UpdateHealth(HealthPoint);

        audioSource.PlayOneShot(audioClip);
    }
}
